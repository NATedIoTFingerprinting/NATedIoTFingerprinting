Scanning events from Saturday November 20 2021 till Thursday November 24 2021

Sat/sun: 20K scanning events 
Sun/Mon: 20K scanning events 
Mon: 15K scanning events 
Tue: 15K scanning events
Wed/Thu: 10K scanning events

Sampled 500K packets

Scanning events from Wed October 20 2021 between 8:44pm and 11:49pm

Mirai Dump Labeled: Number of scanning events: 33,404 events

Sampled 500K packets

